How to Run
Dependencies
Install required libraries:

pip install enchant

This package is used to check if the word is in the english dictionary

Steps
1. Place the input files (Shakespeare.txt) in the same folder as python script.
2. Run the main script:
    python main.py
3. Output text files of Shakespeare with clean text with no punctuations and non-English words and the top 20 frequent words should be populated.
